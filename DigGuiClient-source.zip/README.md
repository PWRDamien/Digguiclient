# DigGui Client (source prototype)

This is **source code**, not a compiled mod JAR. The current prototype draws a draggable ClickGUI and toggles, but does not scan or highlight Minecraft blocks yet.

## Build
1. Generate a Minecraft 1.21.11 Fabric Java project using the official Fabric template generator.
2. Keep the template's Gradle wrapper, Loom setup, and mappings.
3. Copy `DigGuiClient.java` and `DigGuiScreen.java` into `src/main/java/com/diggui/client/`.
4. Merge the `fabric.mod.json` entrypoint/dependencies from this package into the generated template's metadata.
5. Ensure Fabric API is included, then run `./gradlew build` in a Java 21 environment.
6. If it builds, the JAR will be in `build/libs/`.

## iPhone / Amethyst
A regular Fabric mod JAR is not installed as an iOS app. In Amethyst, open the Minecraft instance's mods folder (if that Amethyst build supports Fabric mods) and place the compiled `.jar` there. Restart the instance. Compatibility with the specific Amethyst build is not guaranteed. Do not put the source `.java` files or this ZIP in the mods folder.
