package com.diggui.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class DigGuiScreen extends Screen {
    private int storageX = 35, storageY = 55;
    private int spawnerX = 250, spawnerY = 55;
    private boolean storageEnabled, spawnerEnabled;
    private boolean draggingStorage, draggingSpawner;
    private double dragOffsetX, dragOffsetY;
    private int opacity = 210, colorIndex;
    private final int[] colors = {0xFF4DA3FF, 0xFFB36BFF, 0xFF45D6A0, 0xFFFFB454};

    public DigGuiScreen() {
        super(Component.literal("DigGui"));
    }

    @Override
    protected void init() {
        storageX = Math.max(10, Math.min(storageX, width - 205));
        spawnerX = Math.max(10, Math.min(spawnerX, width - 205));
        storageY = Math.max(10, Math.min(storageY, height - 130));
        spawnerY = Math.max(10, Math.min(spawnerY, height - 130));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0x99060910);
        int accent = colors[colorIndex];
        g.fill(20, 15, width - 20, 43, 0xEE101522);
        g.fill(20, 15, 23, 43, accent);
        g.drawString(font, "DIGGUI CLIENT", 32, 25, 0xFFFFFFFF, false);
        g.drawString(font, "1.21.11 / FABRIC", width - 145, 25, 0xFF9CAAC0, false);

        drawPanel(g, storageX, storageY, "STORAGE FINDER", storageEnabled, accent);
        drawPanel(g, spawnerX, spawnerY, "SPAWNER FINDER", spawnerEnabled, accent);

        int sy = height - 70;
        g.fill(20, sy, width - 20, height - 20, 0xEE101522);
        g.drawString(font, "THEME", 32, sy + 12, 0xFFFFFFFF, false);
        g.fill(100, sy + 10, 120, sy + 30, accent);
        g.drawString(font, "Tap theme to change", 132, sy + 12, 0xFFB8C2D6, false);
        g.drawString(font, "Opacity: " + opacity, 32, sy + 40, 0xFFFFFFFF, false);
        g.drawString(font, "Drag panel headers to move", width - 190, sy + 40, 0xFFB8C2D6, false);
        super.render(g, mouseX, mouseY, delta);
    }

    private void drawPanel(GuiGraphics g, int x, int y, String title, boolean enabled, int accent) {
        g.fill(x, y, x + 190, y + 115, ((opacity & 255) << 24) | 0x00101522);
        g.fill(x, y, x + 190, y + 2, accent);
        g.fill(x, y, x + 190, y + 27, 0xFF202A3B);
        g.drawString(font, title, x + 9, y + 10, 0xFFFFFFFF, false);
        g.fill(x + 10, y + 39, x + 180, y + 63, enabled ? accent : 0xFF303849);
        g.drawCenteredString(font, enabled ? "ENABLED" : "DISABLED", x + 95, y + 47, 0xFFFFFFFF);
        g.drawString(font, title.startsWith("STORAGE") ? "Containers: 4 types" : "Target: mob spawners",
            x + 10, y + 75, 0xFFB8C2D6, false);
        g.drawString(font, "Module settings", x + 10, y + 92, 0xFF8291AA, false);
    }

    private boolean hit(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int sy = height - 70;
        if (mouseY >= sy && mouseY <= sy + 35 && mouseX >= 90 && mouseX <= 125) {
            colorIndex = (colorIndex + 1) % colors.length;
            return true;
        }
        if (mouseY >= sy + 35 && mouseY <= height - 20) {
            opacity = opacity >= 240 ? 100 : opacity + 35;
            return true;
        }
        if (hit(mouseX, mouseY, storageX, storageY, 190, 27)) {
            draggingStorage = true; dragOffsetX = mouseX - storageX; dragOffsetY = mouseY - storageY; return true;
        }
        if (hit(mouseX, mouseY, spawnerX, spawnerY, 190, 27)) {
            draggingSpawner = true; dragOffsetX = mouseX - spawnerX; dragOffsetY = mouseY - spawnerY; return true;
        }
        if (hit(mouseX, mouseY, storageX + 10, storageY + 39, 170, 24)) {
            storageEnabled = !storageEnabled; return true;
        }
        if (hit(mouseX, mouseY, spawnerX + 10, spawnerY + 39, 170, 24)) {
            spawnerEnabled = !spawnerEnabled; return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (button == 0 && draggingStorage) {
            storageX = clampX(mouseX - dragOffsetX); storageY = clampY(mouseY - dragOffsetY); return true;
        }
        if (button == 0 && draggingSpawner) {
            spawnerX = clampX(mouseX - dragOffsetX); spawnerY = clampY(mouseY - dragOffsetY); return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    private int clampX(double x) { return (int)Math.max(0, Math.min(x, width - 190)); }
    private int clampY(double y) { return (int)Math.max(0, Math.min(y, height - 115)); }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        draggingStorage = false; draggingSpawner = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
